#SBATCH -p Lewis
#SBATCH -N 2
#SBATCH -n 4